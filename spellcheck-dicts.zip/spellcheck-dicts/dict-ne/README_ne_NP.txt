README Nepali SpellChecking Dictionary
Release 1.1 2006-10-17
License: LGPL 2.1

Nepali SpellChecking Dictionary
Compiled by Madan Puraskar Pustakalaya
Patan Dhoka, Lalitpur
Nepal
URL: http://nepalinux.org/downloads/

Contributors:
Amar Gurung (amar@mpp.org.np)
Bal Krishna Bal (bal@mpp.org.np)
Basanta Karki (basanta_karki@mpp.org.np)
Basanta Shrestha (basanta@mpp.org.np)
Ishwor Sharma (ishwar@mpp.org.np)
Laxmi Prasad Khatiwada (lkhatiwada@mpp.org.np)
Paras Pradhan (paras@mpp.org.np)
Prajol Shrestha (prajol@mpp.org.np)
Subir Pradhanang (subir@mpp.org.np)

Acknowledgement:
This work has been possible through the support of National University
of Computer and Emerging Sciences (NUCES), Pakistan, and Pan Asia
Networking (PAN) program of International Development Research Center
(IDRC), Canada.
