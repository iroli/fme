name   :  Korean(ko_KR) spellcheck dictionary
date   :  2023. 05. 14
License:  LGPL-3.0

- The dictionary files (ko_KR.aff and ko_KR.dic) were built from the Korean hunspell dictionary project(https://github.com/spellcheck-ko/hunspell-dict-ko) by Changwoo Ryu.
- Update dictionary file (ko_KR.dic) by DaeHyun Sung (2023. 05.14)
