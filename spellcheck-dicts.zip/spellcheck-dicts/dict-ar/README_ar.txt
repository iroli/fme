Arabic Spellchecker for Openoffice.org 3.0
------------------------------------------

Welcome!

This is a package I made for Openoffice.org Arabic spellchecker. I did NOT write this checker, I merely packaged the checker provided by the Ayaspell project[1] into a format recognized by Openoffice.org 3.0.

Any improvements are welcome.

[1] http://ayaspell.sourceforge.net/


--
Ahmad Farghal | ahmad.farghal@gmail.com
