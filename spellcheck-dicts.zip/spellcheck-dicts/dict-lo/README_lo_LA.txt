name   :  lo_LA 0.1 version of the Lao dictionary
date   :  2013.11.21
License:  LGPL
Copyright 2013 by Brian Eugene Wilson, Robert Martin Campbell

Lao Dictionary to help improve LibreOffice
