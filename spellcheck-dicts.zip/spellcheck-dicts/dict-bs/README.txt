The contents of this software may be used under the terms of
the GNU General Public License Version 2 or later or
the GNU Lesser General Public License Version 2.1 or later or 
the Mozilla Public License Version 1.1 or later.

Software distributed under these licenses is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the licences
for the specific language governing rights and limitations under the licenses.
