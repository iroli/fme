lopts = {}
lopts_default = {}
lopts['hu_HU'] = [u'cap', u'par', u'quot', u'wordpart', u'dash', u'comma', u'numpart', u'grammar', u'style', u'dup0', u'compound', u'dup', u'allcompound', u'dup2', u'money', u'dup3', u'SI', u'hyphen', u'apost', u'spaces', u'frac', u'ligature', u'elli', u'spaces2', u'thin', u'noligature', u'idx', u'minus']
lopts_default['hu_HU'] = [u'dash', u'dup0', u'money', u'apost', u'spaces']
