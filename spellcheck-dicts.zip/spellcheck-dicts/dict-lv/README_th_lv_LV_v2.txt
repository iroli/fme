# Latviešu valodas sinonīmu vārdīca (tezaurs)
# lietošanai ar OpenOffice 3.1.x un augstāk
# Latvian thesaurus for OpenOffice 3.1.x and higher
#
# Copyright (C) 2010-2020 Janis Eisaks, jancs@dv.lv, http://dict.dv.lv
#
# Šī bibliotēka tiek licencēta ar Lesser General Public Licence (LGPL) 2.1 nosacījumiem. 
# Licences nosacījumi pievienoti failā license.txt vai iegūstami tīmekļa vietnē  
# http://www.fsf.org/licensing/licenses/lgpl.html
# 
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# license along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
#
# Vārdnīcas izstrādē izmantotā literatūra:
# (pagaidām tiek apzināta)
#
# Pateicības
# - linux.lv vēstkopas aktīvistiem par padomiem vārdnīcas apstrādes skriptu rakstīšanā
# - Oskaram Vīksnam par izpalīdzību ar C++
#

1. Version info
2. Uzstādīšana
3. Interesentiem
4. Izmaiņu saraksts

==================
1. Version info 0.0.1
- nav uzskatāma par izmatojamu vārdnīcu, 

=================
2. Vārdīcas uzstādīšana

Tā kā vārdnīca ir ietverta OpenOffice latviešu valodas paplašinājuma komplektā, atsevišķa 
uzstādīšana nav nepieciešama.
Ja nevēlaties izmantot sinonīmu bibliotēku, to var atslēgt izvēlnē

Tools/Language Settings/Writing Aids

izķeksējot rindiņu pie Thesaurus (atslēgs visus) vai arī nospiežot pogu Edit un atslēdzot
to konkrētai valodai.

=================
3. Interesentiem

Skat. http://dict.dv.lv sadaļā Sinonīmi/Dokumentācija

=================
4. Izmaiņu saraksts
=================
