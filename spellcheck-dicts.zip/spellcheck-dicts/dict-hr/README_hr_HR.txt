# Husnpellov rječnik za računalnu provjeru pravopisa hrvatskog jezika


GPL 2.0/LGPL 2.1/MPL 1.1 tri-license

-----

repository: https://www.github.com/krunose/hr-hunspell

-----

### Autori i doprinositelji ###


Boris Juric, 2017. - 2018.

-----

Mirko Kos (m i r k o s 9 9 [ a t ] g m a i l // c o m), 2016. - 2017.

-----

Krunoslav Šebetić (k r u n o . s e [ a t ] g m x // c o m), 2014. - 2018.

-----

Denis Lackovic (http://cvs.linux.hr/spell/), 2003.
