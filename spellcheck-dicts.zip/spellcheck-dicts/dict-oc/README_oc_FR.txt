Diccionari OCCITAN-Lengadocian version 1.5

Aquela version del corrector Occitan Lengadocian es la primièra version que seguís la version bèta, version de tèst.
Lo fichièr diccionari e lo dels afixes foguèron creats per Bruno GALLART, Cédric Valmary de l'Association Tot En Òc (totenoc.eu).

Aquesta version 0.1 es la frucha de mantuna annada de collècta, e de confrontacions de donadas.
Mercejam particularament lo CIRDÒC pel bon acuèlh que faguèt al projècte e pels tèsts en situacion que sos collaborators an realizats per nosautres.

Totas vòstras remarcas seràn benvengudas : dev@openoc.org



Dictionnaire OCCITAN-Languedocien version 1.5


Cette version du correcteur ortographique Occitan-Languedocien est la première qui fait suite à la version bèta, version de test.
Le fichièr dictionnaire et celui des affixes ont été crées par Bruno GALLART, Cédric VALMARY et l'association Tot En Òc (totenoc.eu).

Cette version 0.1 est le fruit de plusieurs années de collecte, e de confrontations de données.
Nous remercions particulièrement le CIRDÒC pour le bon accueil qu'il a fait au projet et pour les tests en situation que ses collaborateurs ont effectués pour nous.

Toutes vos remarques seront les bienvenues sur le site  : dev@openoc.org



Licéncia, licence :

Occitan Lengadocian wordlist for MySpell version 1.5
Copyright (C) 2006-2022 Bruno GALLART & Cédric VALMARY

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.



REFERÉNCIAS

- Alibèrt Loís (1966) = Alibert Louis, Dictionnaire occitan‑français d’après les parlers languedociens, Tolosa: Institut d’Études Occitanes
- Barta Rogièr (1970) = Barthe Roger, Lexique français‑occitan, París: Collection des amis de la langue d’oc
- Lo CIRDÒC = occitanica.eu
- Congrès Permanent de la Lenga Occitana = locongres.org : Dicodòc, Verbòc...
- Conselh de la Lenga Occitana : Preconizacions del Conselh de la Lenga Occitana 2007 (en linha).
- Lagarde André = La Palanqueta : Dictionnaire occitan-français et français-occitan Broché – 1 décembre 2012
- Lagarde André = Le trésor des mots d'un village occitan (dictionnaire du parler de Rivel), 1991
- Laus Cristian (2001) = Laux Christian , Dictionnaire occitan‑français: languedocien, Reialmont: section du Tarn de l’Institut d’Études Occitanes 
- Mistral Frederic (1879‑1886) = Mistral Frédéric, Lou Tresòr dóu Felibritge: dictionnaire provençal‑français, Ais de Provença: Remondet‑Aubin [reed. 1932, París: Delagrave][reed. 1968, Ais de Provença: Edicioun Ramoun Berenguié][reed. 1979, Ais de Provença: Edisud, 2 volums]
- Sumien Domergue (2006) La standardisation pluricentrique de l’occitan: nouvel enjeu sociolinguistique, développement du lexique et de la morphologie, coll. Publications de l’Association Internationale d’Études Occitanes III, Turnhout: Brepols
- Ubaud Josiana & Sauzet Patric (1995) = Sauzet Patrick, & Ubaud Josiane, Le verbe occitan: guide complet de conjugaison selon les parlers languedociens/Lo vèrb occitan: guida completa de conjugason segon los parlars lengadocians, Ais de Provença: Edisud
- Ubaud Josiana = Pensabèstia ortografic. 26/02/2013. (en linha)
- Ubaud Josiana = Diccionari ortografic, gramatical e morfologic de l'occitan. Canet: Trabucaire. 2011.
- Ubaud Josiana = Diccionari scientific francés-occitan: matematica-informatica-fisica-tecnologia-quimia (lengadocian e provençau). Lo Crèç: Nerta edicion. 2014.
